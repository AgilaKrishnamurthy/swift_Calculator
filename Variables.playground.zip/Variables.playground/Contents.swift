import UIKit

var greeting: String = "Hello, playground"
greeting = "Hi"

var num = 1
num += 20
let test = 5
